package com.example.unnati;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnnatiApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnnatiApplication.class, args);
	}

}
