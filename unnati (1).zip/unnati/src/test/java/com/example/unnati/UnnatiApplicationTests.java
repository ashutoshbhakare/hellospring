package com.example.unnati;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnnatiApplicationTests {

	@Test
	void contextLoads() {
	}

}
